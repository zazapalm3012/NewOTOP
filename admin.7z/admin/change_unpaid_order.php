<?php
$id = $_GET['id'];
include_once("connectDB.php");
$conn = new DB_conn;
$sql = $conn -> unpaid_order($id);
if($sql){
    echo "<script>alert ('ปรับสถานะการสั่งซื้อเสร็จสิ้น');</script>";

    echo "<script>window.location.href='table_order.php' </script>";
}
else{
    echo "<script>alert ('ไม่สามารถปรับสถานะการสั่งซื้อได้');</script>";
    
}


?>